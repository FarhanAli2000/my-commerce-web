// config.js
const config = {
  publicPath: "/",
};

export default config;
